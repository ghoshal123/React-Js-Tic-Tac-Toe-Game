import "./App.css";
import Player from "./Game/Player";


function App() {
  return (
    <div className="App">
    <Player/>
    </div>
  );
}

export default App;
